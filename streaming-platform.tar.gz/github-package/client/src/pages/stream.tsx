import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import InputSelector from "@/components/InputSelector";
import StreamPlayer from "@/components/StreamPlayer";
import StreamControls from "@/components/StreamControls";
import StreamHealth from "@/components/StreamHealth";
import StreamOutputs from "@/components/StreamOutputs";
import RecordingSettings from "@/components/RecordingSettings";
import RecordingsGallery from "@/components/RecordingsGallery";
import { Bug } from "lucide-react";
import type { Stream } from "@shared/schema";

export default function StreamPage() {
  const [selectedStream, setSelectedStream] = useState<Stream | null>(null);

  const { data: streams = [], isLoading } = useQuery<Stream[]>({
    queryKey: ['/api/streams']
  });

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-4xl font-bold text-foreground">Video Streaming Platform</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card>
              <CardContent className="p-4">
                <StreamPlayer stream={selectedStream} />
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card>
              <CardContent className="p-4">
                <InputSelector 
                  streams={streams}
                  isLoading={isLoading}
                  selectedStream={selectedStream}
                  onSelectStream={setSelectedStream}
                />
              </CardContent>
            </Card>

            {selectedStream && (
              <>
                <Card>
                  <CardContent className="p-4">
                    <StreamControls stream={selectedStream} />
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <StreamHealth stream={selectedStream} />
                  </CardContent>
                </Card>

                <StreamOutputs stream={selectedStream} />

                <RecordingSettings stream={selectedStream} />
              </>
            )}
          </div>
        </div>

        {/* Recordings Gallery - Full width */}
        <div className="col-span-2">
          <RecordingsGallery streamId={selectedStream?.id} />
        </div>
      </div>
    </div>
  );
}