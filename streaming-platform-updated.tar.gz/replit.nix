{pkgs}: {
  deps = [
    pkgs.ffmpeg
  ];
}
